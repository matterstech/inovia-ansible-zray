<?php
namespace ZendServer\Filter;

interface FilterInterface 
{
    public function getType(); 
}