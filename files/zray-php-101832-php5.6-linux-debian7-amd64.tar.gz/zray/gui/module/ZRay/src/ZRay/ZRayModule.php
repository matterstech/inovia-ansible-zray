<?php

namespace ZRay;

abstract class ZRayModule extends \DevBar\ZRayModule {
}