<?php
namespace DevBar\View\Helper;

class Test__PHP_Incomplete_Class extends \__PHP_Incomplete_Class {
	private $private = 'private';
	protected  $protected = 'protected';
	public $public = 'public';
	public $__PHP_Incomplete_Class_Name = 'DevBar\View\Helper\superglobalsTest';
}

class superglobalsTest {
	private $private = 'private';
	protected  $protected = 'protected';
	public $public = 'public';
}