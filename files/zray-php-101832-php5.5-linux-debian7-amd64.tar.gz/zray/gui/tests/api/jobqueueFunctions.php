<?php
class ZendJobQueueException extends \Exception {}
