<?php

namespace Vhost\Reply;

class Exception extends \Exception {
	const CODE_APACHE_CONFIGURATION_INVALID = 1000;
}

