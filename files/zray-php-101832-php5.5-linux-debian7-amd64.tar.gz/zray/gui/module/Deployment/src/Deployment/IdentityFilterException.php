<?php
/**
 * Created by JetBrains PhpStorm.
 * User: yonni
 * Date: 5/22/13
 * Time: 1:35 PM
 * To change this template use File | Settings | File Templates.
 */

namespace Deployment;


class IdentityFilterException extends \Exception {
    const EMPTY_APPLICATIONS_ARRAY = 1000;
}