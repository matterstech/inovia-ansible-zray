<?php

namespace ZendServer;

interface EditionAwareInterface {
	/**
	 * @param Edition $edition
	 */
	public function setEdition($edition);
}

